$(document).ready(function() {
    if ($('#alertSuccess').text().trim() == "") {
        $('#alertSuccess').hide();
    }

    $('#alertError').hide();
})

// SAVE
$(document).on("click","#btnSave", function(event) {
    // Clear alerts
    $("#alertSuccess").text(""); 
    $("#alertSuccess").hide(); 
    $("#alertError").text(""); 
    $("#alertError").hide();

    // Form validation
    var status = validateItemForm(); 
    if (status != true) 
    { 
        $("#alertError").text(status); 
        $("#alertError").show(); 
        return; 
    } 

    // If valid
    $("#formItem").submit(); 
})

// UPDATE
//to identify the update button we didn't use an id we used a class
$(document).on("click", ".btnUpdate", function(event) 
{ 
    $("#hidItemIDSave").val($(this).closest("tr").find('#hidItemIDUpdate').val()); 
    $("#name").val($(this).closest("tr").find('td:eq(0)').text()); 
    $("#amount").val($(this).closest("tr").find('td:eq(1)').text()); 
    $("#description").val($(this).closest("tr").find('td:eq(2)').text()); 
}); 


// CLIENT-MODEL================================================================ 
function validateItemForm() { 
    // CODE 
    if ($("#name").val().trim() == "") 
    { 
        return "Insert Item Code."; 
    } 

    // NAME 
    if ($("#amount").val().trim() == "") 
    { 
        return "Insert Item Name."; 
    } 
    
    // DESCRIPTION------------------------ 
    if ($("#description").val().trim() == "") 
    { 
        return "Insert Item Description."; 
    } 
    
    return true; 
} 
 