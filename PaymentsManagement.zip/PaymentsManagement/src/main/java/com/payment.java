package com;

import java.sql.*;

public class payment {

    public Connection connect(){
    	
        //database connection details
        String dbDriver = "com.mysql.jdbc.Driver";
        String dbURL = "jdbc:mysql://localhost:3306/";
        String dbName = "paymentadd";
        String dbUsername = "root";
        String dbPassword = "";
        
        Connection conn = null;

        try {
        	//connecting the database
        	Class.forName(dbDriver);
        	conn = DriverManager.getConnection(dbURL+dbName, dbUsername, dbPassword);
        	
        	//if successfully connected this will be printed in the terminal
        	System.out.print("Database connected successfully");
        } catch(Exception e) {
        	e.printStackTrace();
        }
        
        return conn;
    }

    //method to insert data
    public String insertpayment(String name, String amount,  String description) {
    	Connection conn = connect();
    	
    	String Output = "";
    	
    	try {
        	if (conn == null) {
        		return "Database connection error";
        	}
        	
        	//SQL query
        	String query = "INSERT INTO paymentes (name,amount,description) VALUES (?,?,?)";
        	
        	//binding data to SQL query
        	PreparedStatement preparedStatement = conn.prepareStatement(query);
        	preparedStatement.setString(1, name);
        	preparedStatement.setString(2, amount);
        	preparedStatement.setString(3, description);
        	
        	//execute the SQL statement
        	preparedStatement.execute();
        	conn.close();
        	
        	Output = "payment inserted successfully";
        	
    	} catch(Exception e) {
    		Output = "Failed to insert the payment";
    		System.err.println(e.getMessage());
    	}
    	
    	return Output;
    }
    
    //method to update data
    public String updatepayment(String id, String name, String amount, String description) {
    	Connection conn = connect();
    	
    	String Output = "";
    	
    	try {
        	if (conn == null) {
        		return "Database connection error";
        	}
        	
        	//SQL query
        	String query = "UPDATE paymentes SET name = ?,amount = ?,description = ? WHERE id = ?";
        	
        	//binding data to SQL query
        	PreparedStatement preparedStatement = conn.prepareStatement(query);
        	preparedStatement.setString(1, name);
        	preparedStatement.setString(2, amount);
        	preparedStatement.setString(3, description);
        	preparedStatement.setString(4, id);
        	
        	//execute the SQL statement
        	preparedStatement.executeUpdate();
        	conn.close();
        	
        	Output = "payment updated successfully";
        	
    	} catch(Exception e) {
    		Output = "Failed to update the payment";
    		System.err.println(e.getMessage());
    	}
    	
    	return Output;
    }
    
    
    //method to read data
    public String readpayment() {
    	Connection conn = connect();
    	
    	String Output = "";
    	
    	try {
        	if (conn == null) {
        		return "Database connection error";
        	}
        	
        	//SQL query
        	String query = "SELECT * FROM paymentes";
        	
        	//executing the SQL query
        	Statement statement = conn.createStatement();
        	ResultSet resultSet = statement.executeQuery(query);
        	
        	// Prepare the HTML table to be displayed
    		Output = "<table border='1'><tr><th>Name</th>" +"<th>amount</th>"
    		+ "<th>payment Description</th>"
    		+ "<th>Update</th><th>Remove</th></tr>";

        	while(resultSet.next()) {
        		String id = Integer.toString(resultSet.getInt("id"));
        		String name = resultSet.getString("name");
        		String amount = resultSet.getString("amount");
        		String description = resultSet.getString("description");

        		// Add a row into the HTML table
        		Output += "<tr><td><input id='hidItemIDUpdate' name='hidItemIDUpdate' type='hidden' value='"+id+"'>" + name + "</td>"; 
        		Output += "<td>" + amount + "</td>"; 
        		Output += "<td>" + description + "</td>";

        		// buttons
        		Output += "<td><input name='btnUpdate' type='button' value='Update' class='btnUpdate btn btn-sm btn-secondary'></td>" 
        				+ "<td><form method='post' action='paymanage.jsp'>"
        				+ "<input name='btnRemove' type='submit' value='Remove' class='btn btn-sm btn-danger'>"
        				+ "<input name='hidItemIDDelete' type='hidden' value='" + id + "'>"
        				+ "</form></td></tr>";
        	}

        	conn.close();
        	
        	// Complete the HTML table
        	Output += "</table>";
        	
    	} catch(Exception e) {
    		Output = "Failed to read the paymentes";
    		System.err.println(e.getMessage());
    	}
    	
    	return Output;
    }
    
    //method to delete data
    public String deletepayment(String id) {
    	String Output = "";
    	Connection conn = connect();
    	
    	try {
        	if (conn == null) {
        		return "Database connection error";
        	}
        	
        	//SQL query
        	String query = "DELETE FROM paymentes WHERE id = ?";
        	
        	//binding data to the SQL query
        	PreparedStatement preparedStatement = conn.prepareStatement(query);
        	preparedStatement.setInt(1, Integer.parseInt(id));
        	
        	//executing the SQL statement
        	preparedStatement.execute();
        	conn.close();
        	
        	Output = "Deleted successfully";
        	
    	} catch(Exception e) {
    		Output = "Failed to delete the payment";
    		System.err.println(e.getMessage());
    	}
    	return Output;
    }
}
